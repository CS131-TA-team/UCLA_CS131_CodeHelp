// 7 - atomic
import java.util.concurrent.atomic.AtomicIntegerArray;

class C7 {
  public static void main(String[] args) throws InterruptedException {
    final AtomicIntegerArray zero = new AtomicIntegerArray(1);

    Thread thread_1 = new Thread() {
      public void run(){
        for(int i = 0; i < 1000000; i ++){
          // zero[i] will be split into 3 ops:
          //    thread local int x = zero[0];
          //    x = x + i;
          //    zero[0] = x
          // Which competes with thread2.
          // But an atomic operation is not splitable:
          zero.getAndAdd(0, i);
        }
      }
    };
    Thread thread_2 = new Thread() {
      public void run(){
        for(int i = 0; i < 1000000; i ++){
          zero.getAndAdd(0, -i);
        }
      }
    };
    // Start them
    thread_1.start();
    thread_2.start();
    // Wait for them to finish
    thread_1.join();
    thread_2.join();
    // Output the result
    System.out.println(zero.get(0));  // 0


    // This time it works, but what if we have more complicated operations?
  }
}
