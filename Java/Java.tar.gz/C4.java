// 4 - Generics

// Generics are like C++'s template
// (differences will be covered by the professor after midterm)
class Arr<T>{
  private T[] mem = null;

  Arr(int size){
    @SuppressWarnings("unchecked")  // Used to supress a warning
    T[] mem = (T[])new Object[size];  // This line is considered unsafe because you cast Object to T
    this.mem = mem;
  }
  public T get(int i){
    return mem[i];
  }
  public void set(int i, T obj){
    mem[i] = obj;
  }
  public void print(){
    for(int i = 0; i < mem.length; i ++){
      System.out.println("[" + Integer.toString(i) + "]" + " : " +
                         mem[i].getClass().getName() + " = " +
                         mem[i].toString());
      // We can do this because getClass() and toString() are defined by Object
      // And Object is the base class for any T
    }
  }
}


class C4 {
  public static void main(String args[]) {
    Arr<Integer> arr = new Arr<Integer>(3);
    arr.set(0, 1);
    arr.set(1, 10);
    arr.set(2, 100);
    arr.print();
  }
}
