// 9 - lock
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.ThreadLocalRandom;

class SyncedBank {
  int[] account = new int[2];
  ReentrantLock[] locks = new ReentrantLock[2];
  SyncedBank(int a0, int a1){
    account[0] = a0;
    account[1] = a1;
    locks[0] = new ReentrantLock();
    locks[1] = new ReentrantLock();
  }

  public boolean transfer(int source, int amount) {
    int dest = source ^ 1;

    // It's safe to read simultaneously
    if(account[source] < amount){
      return false;
    }
    // But we need to check again after lock
    locks[source].lock();
    try{
      if(account[source] < amount){
        return false;
      }
      account[source] -= amount;
    }finally{
      locks[source].unlock();  // finally ensures this line to execute
    }

    // We cannot acquire 2 locks at the same time -> dead lock
    locks[dest].lock();
    try{
      account[dest] += amount;
    }finally{
      locks[dest].unlock();
    }
    

    if(account[0] < 0 || account[1] < 0){
      System.out.println("Oops");  // It will never be negative
    }
    return true;
  }

  public void print() {
    System.out.println(Integer.toString(account[0]) + " " + Integer.toString(account[1]));
  }
}

class MyThreadMain implements Runnable {  // This time 2 threads are the same, so we do slightly differently
  SyncedBank bank;

  @Override
  public void run() {
    for(int i = 0; i < 1000000; i ++){
      int source = ThreadLocalRandom.current().nextInt(2);
      int amount = ThreadLocalRandom.current().nextInt(1000);
      bank.transfer(source, amount);
    }
  }

  MyThreadMain(SyncedBank bank){
    super();
    this.bank = bank;
  }
}

class C9 {
  public static void main(String[] args) throws InterruptedException {
    final SyncedBank bank = new SyncedBank(1000, 1000);

    Thread thread_1 = new Thread(new MyThreadMain(bank));
    Thread thread_2 = new Thread(new MyThreadMain(bank));
    // Start them
    thread_1.start();
    thread_2.start();
    // Wait for them to finish
    thread_1.join();
    thread_2.join();
    // Output the result
    bank.print();
  }
}
