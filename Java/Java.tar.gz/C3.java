// 3 - Interfaces

import java.util.Arrays;

// But there are interfaces
interface Printable {
  // All methods in interfaces are abstract (=without implementation) and public
  // Keyword 'public' and 'abstract' are omittable
  abstract void print();
}

// Comparable<T> is a built-in interface used by sort
class User implements Printable, Comparable<User> {
  private int uid = 0;
  private String name = null;  // null is empty pointer

  // Override Printable's print
  @Override
  public void print() {
    System.out.println(Integer.toString(uid) + " - " + name);
  }

  // Override Comparable<User>'s compareTo
  @Override
  public int compareTo(User rhs) { 
    return this.uid - rhs.uid;  // this means current instance, omittable
  }

  User(int uid, String name) {
    this.uid = uid;
    this.name = name;
  }
}

class C3 {
  public static void main(String args[]) {
    User[] users = new User[2];
    users[0] = new User(1, "Alice");
    users[1] = new User(0, "Bob");

    // A class can be cast to its interface
    Printable alice = users[0];
    alice.print();

    // And we can sort because Comparable is implemented
    Arrays.sort(users);
    users[0].print();

    // Downcast can succeed only if alice is a real User.
    // If alice is not, a runtime Exception.
    User alice2 = (User)alice;
    alice2.print();
  }
}
