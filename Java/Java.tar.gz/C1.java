// 1 - Classes

// A class is a prototype of objects, it defines a set of fields and methods.
class Users {
  // A field called names, which is a string array
  //Non-formal EBNF:
  // [visibility], ['static'], type, field name, ['=', initial value], ';'
  private String[] names;
  // A non-static field belongs to instances; a static field belongs to the class, shared by all instances.

  // Constructor method has the name of class name
  Users(){
    // Create an object:
    // 'new', class name, ['(', arguments, ')']
    // But array is special:
    // 'new', class name, '[', size, ']'
    names = new String[2];

    // Basic grammar is just like C.
    names[0] = "Alice";
    names[1] = "Bob";
  }

  // Method is defined as:
  // [visibility], ['static'], return type, method name, '(', argument list, ')', body
  // A non-static method belongs to instances and be able to access all fields;
  // A static method can only access static fields and methods.
  public String get(int uid){
    return names[uid];
  }
}

class C1 {
  public static void main(String args[]) {
    Users users = new Users();
    System.out.println(users.get(0)); // Alice
    System.out.println(users.get(1)); // Bob
  }
}
