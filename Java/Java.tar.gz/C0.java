// 0 - Hello World

// A Java program is made up with classes
class C0 {
  // The entry is a static method main
  public static void main(String args[]) {
    System.out.println("Hello world!");
  }
}
