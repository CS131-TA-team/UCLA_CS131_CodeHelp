// 8 - synchronized
import java.util.concurrent.ThreadLocalRandom;

class SyncedBank {
  int[] account = new int[2];
  SyncedBank(int a0, int a1){
    account[0] = a0;
    account[1] = a1;
  }

  //synchronized method can only be entered once a time
  public synchronized boolean transfer(int source, int amount) {
    // Use "synchronized(this){...}" if we only need a code block.

    // If there is not enough balance
    if(account[source] < amount){
      return false;
    }
    account[source] -= amount;
    account[source ^ 1] += amount;

    if(account[0] < 0 || account[1] < 0){
      System.out.println("Oops");  // It will never be negative
    }
    return true;
  }

  public void print() {
    System.out.println(Integer.toString(account[0]) + " " + Integer.toString(account[1]));
  }
}

class MyThreadMain implements Runnable {  // This time 2 threads are the same, so we do slightly differently
  SyncedBank bank;

  @Override
  public void run() {
    for(int i = 0; i < 1000000; i ++){
      int source = ThreadLocalRandom.current().nextInt(2);
      int amount = ThreadLocalRandom.current().nextInt(1000);
      bank.transfer(source, amount);
    }
  }

  MyThreadMain(SyncedBank bank){
    super();
    this.bank = bank;
  }
}

class C8 {
  public static void main(String[] args) throws InterruptedException {
    final SyncedBank bank = new SyncedBank(1000, 1000);

    Thread thread_1 = new Thread(new MyThreadMain(bank));
    Thread thread_2 = new Thread(new MyThreadMain(bank));
    // Start them
    thread_1.start();
    thread_2.start();
    // Wait for them to finish
    thread_1.join();
    thread_2.join();
    // Output the result
    bank.print();
  }
}
