// 2 - Dynamic Dispatch

class Users {
  private String[] names;
  Users(){
    names = new String[2];
  }
  public String get(int uid){
    return names[uid];
  }
  protected void set(int uid, String name){
    names[uid] = name;
  }
}

// A class can extend <=1 base class.
// Actually all classes is derived from Object class.
class UsersImpl extends Users {
  // Derived class inherites all fields and methods, but some are invisible.

  // Access Modifiers' matrix:
  //           Self  Package  Subclass  World
  // private    OK     --        --       --
  // (empty)    OK     OK        --       --
  // protected  OK     OK        OK       --
  // public     OK     OK        OK       OK

  // A non-static method with the same name and args can override the method from the base class.
  @Override  // @Override is an optional annotation
  public String get(int uid){
    // return names[uid]; // names is not visible
    return Integer.toString(uid) + " - " + super.get(uid); // super is used to call overrided method
  }

  // Constructor is special, unable to override
  UsersImpl(String name1, String name2){
    super();  // But it can call the base class' constructor
    // Again names is invisible
    set(0, name1);
    set(1, name2);
  }
}

class C2 {
  public static void main(String args[]) {
    // Subclasses are subtypes
    Users users = new UsersImpl("Alice", "Bob");
    // Overrided methods will be called
    System.out.println(users.get(0)); // 0 - Alice
    System.out.println(users.get(1)); // 1 - Bob
  }
}
