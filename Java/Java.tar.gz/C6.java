// 6 - Threads
class C6 {
  public static void main(String[] args) throws InterruptedException {
    // "final" means we cannot write: zero = ...;
    // But again, objects are mutable. This is allowed: zero[0] ++;
    final int[] zero = new int[1];

    Thread thread_1 = new Thread() {  // This creates an anonymous subclass
      public void run(){  // run() is the Thread main function
        for(int i = 0; i < 1000000; i ++)
          zero[0] += 1;  // variables refered in an inner class should be "final", that's why we use use an array
      }
    };
    Thread thread_2 = new Thread() {
      public void run(){
        for(int i = 0; i < 1000000; i ++)
          zero[0] -= 1;
      }
    };
    // Start them
    thread_1.start();
    thread_2.start();
    // Wait for them to finish
    thread_1.join();
    thread_2.join();
    // Output the result
    System.out.println(zero[0]);

    // But wait, why it's not 0?
  }
}
