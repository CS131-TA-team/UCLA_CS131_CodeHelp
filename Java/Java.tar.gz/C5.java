// 5 - Covariance & Contravariance

// Arr remains the same
// We can explicitly specify that T must be a subclass of Object
// Though it's always true, actually
class Arr<T extends Object>{
  private T[] mem = null;
  Arr(int size){
    @SuppressWarnings("unchecked")
    T[] mem = (T[])new Object[size];
    this.mem = mem;
  }
  public T get(int i){
    return mem[i];
  }
  public void set(int i, T obj){
    mem[i] = obj;
  }
  public void print(){
    for(int i = 0; i < mem.length; i ++){
      System.out.println("[" + Integer.toString(i) + "]" + " : " +
                         mem[i].getClass().getName() + " = " +
                         mem[i].toString());
    }
  }
}

class C5 {
  public static void incompatible(Arr<Integer> int_arr){
    // Why is it forbidden?
    // Arr<Number> num_arr = int_arr;
    // error: incompatible types: Arr<Integer> cannot be converted to Arr<Number>

    // Relationship:
    //     Number
    //      ^  ^
    //   |--|  |--|
    //   |        |
    // Float    Integer
  }

  private static void writeFloats(Arr<Number> num_arr, int len){  // <- Java ovjects are mutable
    for(int i = 0; i < len; i ++){
      // This is OK because Float is a subclass of Number
      num_arr.set(i, i * 0.1f);
      // Method signature: void Arr.set(int i, Number obj)
    }
  }

  private static float sumInts(Arr<Integer> int_arr, int len){
    float ret = 0f;
    for(int i = 0; i < len; i ++){
      // This is OK because Number is a subclass of Integer
      Number cur = int_arr.get(i);
      // Method signature: Integer Arr.get(int i)
      ret += cur.floatValue();
    }
    return ret;
  }

  public static void what_is_wrong() {
    Arr<Integer> arr = new Arr<Integer>(3);
    // writeFloats((Arr<Number>)arr);  // Here is why it's wrong!
  }

  // Observation: writeFloats only writes to Arr, and sumInts only reads from it.
  // So let's write them more generic

  private static void writeFloats2(Arr<? super Float> float_arr, int len){
    for(int i = 0; i < len; i ++){
      float_arr.set(i, i * 0.1f);
    }
  }
  private static float sumInts2(Arr<? extends Number> num_arr, int len){
    float ret = 0f;
    for(int i = 0; i < len; i ++){
      Number cur = num_arr.get(i);
      ret += cur.floatValue();
    }
    return ret;
  }

  public static void main(String args[]) {
    // This time it works as expected

    Arr<Number> arr1 = new Arr<Number>(3);
    writeFloats2(arr1, 3);
    arr1.print();

    Arr<Integer> arr2 = new Arr<Integer>(3);
    arr2.set(0, 1);
    arr2.set(1, 10);
    arr2.set(2, 100);
    System.out.println(sumInts2(arr2, 3));
  }
}
